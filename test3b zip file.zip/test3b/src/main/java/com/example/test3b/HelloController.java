package com.example.test3b;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.sql.*;
public class HelloController implements Initializable {
    public TextField iid;
    public TextField icustomername;
    public TextField imobilenumber;
    public TextField ipizzasize;
    public TextField inumberoftoppings;
    public Label welcomeText;
    @FXML
    private TableView<orders> tableView;
    @FXML
    private TableColumn<orders,Integer > id;
    @FXML
    private TableColumn<orders, String> customername;
    @FXML
    private TableColumn<orders,Integer> mobilenumber;
    @FXML
    private TableColumn<orders,String> pizzasize;
    @FXML
    private TableColumn<orders,Integer> numberoftoppings;
    @FXML
    private TableColumn<orders,Integer> totalbill;
    ObservableList<orders> list = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
    @FXML
    protected void onHelloButtonClick() {
        list.clear();
        tableView.setItems(list);
        populateTable();
    }
    public void populateTable() {
        // Establish a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/db_test3b";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM orders";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String customername = resultSet.getString("customername");
                int mobilenumber = resultSet.getInt("mobilenumber");
                String pizzasize = resultSet.getString("pizzasize");
                int numberoftoppings = resultSet.getInt("numberoftoppings");
                int totalbill = resultSet.getInt("totalbill");
                tableView.getItems().add(new orders(id, customername, mobilenumber, pizzasize, numberoftoppings, totalbill));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void loadData(ActionEvent actionEvent) {
        String getid = iid.getText(); // Getting the ID entered by the user

        // Prepare the JDBC URL and credentials
        String jdbcUrl = "jdbc:mysql://localhost:3306/db_test3b";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            // SQL query using PreparedStatement (safe from SQL injection)
            String query = "SELECT * FROM orders WHERE id = ?";

            try (PreparedStatement pstmt = connection.prepareStatement(query)) {
                pstmt.setInt(1, Integer.parseInt(getid)); // Set the ID value

                ResultSet resultSet = pstmt.executeQuery();

                // Clear any previous data in the list before populating it
                list.clear();

                // Loop through the ResultSet and add rows to the ObservableList
                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String customername = resultSet.getString("customername");
                    int mobilenumber = resultSet.getInt("mobilenumber");
                    String pizzasize = resultSet.getString("pizzasize");
                    int numberoftoppings = resultSet.getInt("numberoftoppings");
                    int totalbill = resultSet.getInt("totalbill");

                    // Add each order object to the list
                    list.add(new orders(id, customername, mobilenumber, pizzasize, numberoftoppings, totalbill));
                }

                // Set the items in the table view
                tableView.setItems(list);

            } catch (SQLException e) {
                e.printStackTrace();  // Print detailed error if query fails
            }

        } catch (SQLException e) {
            e.printStackTrace();  // Print detailed error if connection fails
        }
    }


    public void DeleteData(ActionEvent actionEvent) {
        String getid = iid.getText();
        String jdbcUrl = "jdbc:mysql://localhost:3306/db_test3b";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "DELETE FROM orders WHERE ID= '"+getid+"'";
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void InsertData(ActionEvent actionEvent) {
        String getid = iid.getText();
        String getcustomername = icustomername.getText();
        String getmobilenumber = imobilenumber.getText();
        String getpizzasize = ipizzasize.getText();
        String getnumberoftoppings = inumberoftoppings.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/db_test3b";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "INSERT INTO orders(customername, mobilenumber, pizzasize, numberoftoppings, totalbill) VALUES ('"+customername+"','"+mobilenumber+"','"+pizzasize+"','"+numberoftoppings+"','"+totalbill+"')";

            Statement statement = connection.createStatement();
            statement.execute(query);


            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void UpdateData(ActionEvent actionEvent) {
        String getid = iid.getText();
        String getcustomername = icustomername.getText();
        String getmobilenumber = imobilenumber.getText();
        String getpizzasize = ipizzasize.getText();
        String getnumberoftoppings = inumberoftoppings.getText();


        String jdbcUrl = "jdbc:mysql://localhost:3306/db_test3b";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "UPDATE orders SET customername='"+getcustomername+"',mobilenumber='"+getmobilenumber+"',pizzasize='"+getpizzasize+"',numberoftoppings='"+numberoftoppings+"',totalbill='"+totalbill+"' WHERE id = '"+getid+"' ";
            welcomeText.setText(query);
            Statement statement = connection.createStatement();
            statement.execute(query);
            // Populate the table with data from the database

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void insertData(ActionEvent actionEvent) {
    }
}